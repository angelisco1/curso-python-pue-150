MI_PI = 3.1415

def suma(n1, n2):
    return n1 + n2


def resta(n1, n2):
    return n1 - n2

print(__name__)

if __name__ == "__main__":
    res = suma(2, 2)
    assert res == 4

    res = resta(2, 2)
    assert res == 0

