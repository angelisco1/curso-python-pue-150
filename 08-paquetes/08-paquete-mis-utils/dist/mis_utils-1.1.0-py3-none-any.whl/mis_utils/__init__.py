from .operaciones import suma, multiplica
from .traductor import traduce