from .operaciones import suma
from .traductor import traduce