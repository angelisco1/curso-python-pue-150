from setuptools import setup, find_packages

setup(
  name='mis_utils',
  version='1.1.0',
  description='Paquete con utilidades básicas de operaciones matemáticas y traducciones',
  long_description='## Paquete con utilidades básicas de ...',
  long_description_content_type='text/markdown',
  author='Ángel',
  author_email='angel@gmail.com',
  packages=find_packages()
)